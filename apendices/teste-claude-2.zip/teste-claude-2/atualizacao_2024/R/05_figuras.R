# ==========================================================================
# 05 - Figuras: séries das taxas de mortalidade por suicídio 1996-2024
#      (padronizadas por idade), com linha de tendência de Prais-Winsten
#      Reproduz a estrutura das Figuras 2 (ES) e 3 (RS) do artigo original.
# ==========================================================================
suppressMessages({library(data.table); library(ggplot2)})
setwd("/private/tmp/claude-501/-Users-hugocristo-Dropbox---Aulas-2026-1-PPGP-IA-teste-claude-2/1e41a329-d9e0-450d-9f41-9b1ec253ccab/scratchpad")
SER <- as.data.table(readRDS("data/series_taxas.rds"))
SER[, estrato := factor(estrato, levels=c("Geral","15-29","Masculino","30-59","Feminino","60+"))]
SER[, unid_lab := ifelse(unidade=="ES","Espírito Santo","Região Serrana")]

fig <- function(u, titulo, arq){
  d <- SER[unidade==u]
  ggplot(d, aes(ano, taxa)) +
    geom_vline(xintercept=2020, linetype="dotted", colour="grey55") +
    geom_point(colour="#2b6cb0", size=1.3) +
    geom_smooth(method="lm", se=FALSE, colour="grey20", linewidth=.6, formula=y~x) +
    facet_wrap(~estrato, scales="free_y", ncol=2) +
    labs(title=titulo,
         subtitle="Pontos = taxa observada padronizada por idade; linha = tendência linear; linha pontilhada = fim do estudo original (2020)",
         x="Ano", y="Taxa por 100.000 hab.",
         caption="Fonte: SIM/DATASUS e estimativas populacionais IBGE (POPBR/POPSVS). Elaboração própria em R.") +
    theme_bw(base_size=11) +
    theme(strip.background=element_rect(fill="#e2e8f0"), plot.title=element_text(face="bold"),
          plot.subtitle=element_text(size=8), plot.caption=element_text(size=7, colour="grey40"))
  ggsave(arq, width=9, height=8, dpi=130)
}
fig("ES","Figura A. Mortalidade por suicídio no Espírito Santo, 1996-2024", "fig_ES.png")
fig("RS","Figura B. Mortalidade por suicídio na Região Serrana (ES), 1996-2024", "fig_RS.png")
cat("Figuras geradas: fig_ES.png, fig_RS.png\n")

# tabela de amplitude das taxas (para o texto)
amp <- SER[, .(taxa_1996=round(taxa[ano==1996],1),
               taxa_2020=round(taxa[ano==2020],1),
               taxa_2024=round(taxa[ano==2024],1),
               min=round(min(taxa),1), max=round(max(taxa),1)), by=.(unidade,estrato)]
cat("\n=== Amplitude das taxas padronizadas ===\n"); print(amp[order(unidade,estrato)])
saveRDS(amp,"data/amplitude_taxas.rds")
