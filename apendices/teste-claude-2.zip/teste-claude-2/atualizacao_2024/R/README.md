# Atualização — Suicídio no ES e Região Serrana (1996–2024)

Reanálise em **R 4.5.2** que estende o estudo de Caliman MO et al.
(*Acta Paul Enferm.* 2023;36:eAPE028332) de 2020 para 2024.

## Fontes oficiais
- **Óbitos:** SIM/DATASUS — arquivos definitivos `DOES<ano>.dbc` (1996–2024),
  em `ftp://ftp.datasus.gov.br/dissemin/publicos/SIM/CID10/DORES/`.
  Filtro: causa básica CID-10 **X60–X84**, residentes ≥15 anos.
- **População (denominadores):** IBGE via DATASUS —
  `POPBR` (1996–1999, `/IBGE/POP/`) e `POPSVS` (2000–2024, `/IBGE/POPSVS/`,
  base reconciliada com o Censo 2022).
- **Códigos de município:** tabela `br_municip.cnv` (DATASUS) e API de
  localidades do IBGE (validação dos 11 municípios da Região Serrana).

## Pipeline (executar na ordem)
1. `01_build.R`   — processa o SIM e monta a base de óbitos.
2. `02_pop.R`     — monta a base populacional por sexo × faixa etária.
3. `03_taxas_prais.R` — taxas padronizadas por idade (padrão ES 2010) e
   regressão de **Prais-Winsten** (APC, IC95%, tendência) para 1996–2020
   (validação) e 1996–2024 (atualização).
4. `04_tabela1.R` — Tabela 1 (distribuição por sexo e faixa etária).
5. `05_figuras.R` — Figuras A (ES) e B (RS).
6. `06_comparacao.R` — tabela comparativa (artigo × reprodução × atualização).

## Pacotes
`read.dbc` (CRAN archive), `data.table`, `foreign`, `prais`, `ggplot2`.

## Observação
Os scripts usam um diretório `data/` com os arquivos baixados do DATASUS.
Ajuste o `setwd(...)` no topo de cada script para o seu ambiente.

## Validação
Reprodução do período original (1996–2020): 3.943 óbitos no ES (artigo: 3.922)
e 528 na Região Serrana (artigo: 525); taxa geral do ES em 1996 = 5,8/100 mil
(idêntica ao artigo). Diferenças ~0,5% decorrem de revisões retrospectivas do SIM.
