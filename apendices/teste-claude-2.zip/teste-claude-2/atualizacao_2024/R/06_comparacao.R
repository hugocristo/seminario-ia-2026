# ==========================================================================
# 06 - Tabela comparativa: artigo original (1996-2020) x reprodução x atualização (1996-2024)
# ==========================================================================
suppressMessages(library(data.table))
setwd("/private/tmp/claude-501/-Users-hugocristo-Dropbox---Aulas-2026-1-PPGP-IA-teste-claude-2/1e41a329-d9e0-450d-9f41-9b1ec253ccab/scratchpad")
R <- readRDS("data/prais_result.rds"); r20 <- R$r2020; r24 <- R$r2024

# Tabela 2 do artigo ORIGINAL (Caliman et al., 2023) - valores publicados
orig <- data.table(
 unidade=c(rep("ES",6),rep("RS",6)),
 estrato=rep(c("Geral","Masculino","Feminino","15-29","30-59","60+"),2),
 APC_orig=c(5.1,3.5,6.5,0.6,3.4,0.3, 11,11.6,15.2,-1.9,2.9,3.1),
 p_orig  =c(0.039,0.438,0.012,0.646,0.018,0.625, 0.305,0.55,0.035,0.643,0.001,0.127),
 tend_orig=c("Crescente","Estacionária","Crescente","Estacionária","Crescente","Estacionária",
             "Estacionária","Estacionária","Crescente","Estacionária","Crescente","Estacionária"))

m <- merge(orig, r20[,.(unidade,estrato,APC_rep=APC,p_rep=p,tend_rep=tend)], by=c("unidade","estrato"))
m <- merge(m, r24[,.(unidade,estrato,APC_upd=APC,ic_lo,ic_hi,p_upd=p,tend_upd=tend)], by=c("unidade","estrato"))
m[, estrato:=factor(estrato,levels=c("Geral","Masculino","Feminino","15-29","30-59","60+"))]
setorder(m, unidade, estrato)

cat("================ COMPARAÇÃO DE TENDÊNCIAS ================\n")
cat("orig = Tabela 2 do artigo (1996-2020) | rep = reprodução própria (1996-2020) | upd = atualização (1996-2024)\n\n")
pr <- m[,.(unidade,estrato,
           `Orig APC`=APC_orig, `Orig tend`=tend_orig,
           `Rep APC`=APC_rep, `Rep tend`=tend_rep,
           `Upd APC`=APC_upd, `Upd IC95`=paste0(ic_lo," a ",ic_hi), `Upd p`=p_upd, `Upd tend`=tend_upd)]
print(pr, row.names=FALSE)

# mudanças de classificação entre reprodução 1996-2020 e atualização 1996-2024
cat("\n================ MUDANÇAS AO ESTENDER 2021-2024 ================\n")
chg <- m[tend_rep!=tend_upd, .(unidade,estrato,`de (1996-2020)`=tend_rep,`para (1996-2024)`=tend_upd)]
print(chg, row.names=FALSE)
fwrite(pr, "data/tabela_comparativa.csv")
saveRDS(m, "data/comp.rds")
