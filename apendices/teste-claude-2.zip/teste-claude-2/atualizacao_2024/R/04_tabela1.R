# ==========================================================================
# 04 - Tabela 1: distribuição dos óbitos por suicídio segundo sexo e faixa etária
#      (ES e RS), 1996-2024, com comparação ao artigo original (1996-2020)
# ==========================================================================
suppressMessages(library(data.table))
setwd("/private/tmp/claude-501/-Users-hugocristo-Dropbox---Aulas-2026-1-PPGP-IA-teste-claude-2/1e41a329-d9e0-450d-9f41-9b1ec253ccab/scratchpad")
OB <- as.data.table(readRDS("data/obitos.rds"))

tab1 <- function(dt){
  tot <- nrow(dt)
  f <- function(x) sprintf("%d (%.1f)", x, 100*x/tot)
  data.table(
    Categoria = c("Total","Masculino","Feminino","15-29 anos","30-59 anos","60+ anos"),
    Valor = c(f(tot),
              f(dt[sexo=="M",.N]), f(dt[sexo=="F",.N]),
              f(dt[grupo=="15-29",.N]), f(dt[grupo=="30-59",.N]), f(dt[grupo=="60+",.N])))
}
cat("===== TABELA 1 - ATUALIZADA (1996-2024) =====\n")
cat("\n-- Espírito Santo --\n"); print(tab1(OB[unidade=="ES"]), row.names=FALSE)
cat("\n-- Região Serrana --\n"); print(tab1(OB[unidade=="RS"]), row.names=FALSE)

cat("\n===== Reprodução período original (1996-2020) p/ comparação =====\n")
cat("\n-- Espírito Santo (1996-2020) --\n"); print(tab1(OB[unidade=="ES"&ano<=2020]), row.names=FALSE)
cat("\n-- Região Serrana (1996-2020) --\n"); print(tab1(OB[unidade=="RS"&ano<=2020]), row.names=FALSE)

# proporção RS/ES
cat("\nRS como % do total ES (1996-2024):", sprintf("%.1f%%", 100*OB[unidade=="RS",.N]/OB[unidade=="ES",.N]),"\n")
cat("RS como % do total ES (1996-2020):", sprintf("%.1f%%", 100*OB[unidade=="RS"&ano<=2020,.N]/OB[unidade=="ES"&ano<=2020,.N]),"\n")
