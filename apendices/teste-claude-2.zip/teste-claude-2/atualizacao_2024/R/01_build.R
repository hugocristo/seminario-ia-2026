# ==========================================================================
# Atualização do estudo "Suicídio no Espírito Santo e em sua Região Serrana"
# 01 - Construção das bases de óbitos (SIM) e população (IBGE)
# Fontes: SIM/DATASUS (DORES) e estimativas populacionais IBGE (POPBR/POPSVS)
# ==========================================================================
suppressMessages({library(read.dbc); library(foreign); library(data.table)})
setwd("/private/tmp/claude-501/-Users-hugocristo-Dropbox---Aulas-2026-1-PPGP-IA-teste-claude-2/1e41a329-d9e0-450d-9f41-9b1ec253ccab/scratchpad")

# ---- Municípios da Região Serrana (códigos DATASUS 6 dígitos, de br_municip.cnv)
RS <- c("320010","320030","320140","320170","320190","320334",
        "320450","320455","320460","320503","320506")
RS_nomes <- c("Afonso Cláudio","Alfredo Chaves","Castelo","Conceição do Castelo",
              "Domingos Martins","Marechal Floriano","Santa Leopoldina",
              "Santa Maria de Jetibá","Santa Teresa","Vargem Alta","Venda Nova do Imigrante")

# ---- Faixas etárias (>=15) -> 14 bandas
bandas <- c("15-19","20-24","25-29","30-34","35-39","40-44","45-49",
            "50-54","55-59","60-64","65-69","70-74","75-79","80+")
banda_de_idade <- function(a){            # a = idade em anos (numérica)
  ifelse(a<15, NA,
  ifelse(a>=80,"80+", bandas[pmin(floor((a-15)/5)+1, 13)]))
}
grupo3 <- function(b){ ifelse(b %in% c("15-19","20-24","25-29"),"15-29",
                       ifelse(b %in% c("30-34","35-39","40-44","45-49","50-54","55-59"),"30-59","60+")) }

# ==========================================================================
# 1) ÓBITOS POR SUICÍDIO (SIM/DORES, CID-10 X60-X84, residentes >=15 anos)
# ==========================================================================
idade_sim <- function(x){               # campo IDADE "4NN" anos, "5NN" 100+NN
  x <- sprintf("%03s", as.character(x)); u <- substr(x,1,1); v <- as.integer(substr(x,2,3))
  ifelse(u=="5",100+v, ifelse(u=="4",v, NA_integer_))   # <4xx = menor de 1 ano -> NA (excluído por <15)
}
obitos_list <- list()
for(y in 1996:2024){
  f <- sprintf("data/sim/DOES%d.dbc",y); if(!file.exists(f)) next
  d <- as.data.table(read.dbc(f, as.is=TRUE))
  d <- d[grepl("^X([6-7][0-9]|8[0-4])", CAUSABAS)]          # X60-X84
  d[, mun := substr(as.character(CODMUNRES), 1, 6)]   # DATASUS-6 = IBGE-6 (vale p/ 6 e 7 dígitos)
  d[, idade := idade_sim(IDADE)]
  d[, sexo := ifelse(SEXO=="1","M", ifelse(SEXO=="2","F", NA))]
  d <- d[!is.na(idade) & idade>=15 & !is.na(sexo)]         # exclui idade/sexo ignorados e <15
  d[, banda := banda_de_idade(idade)]
  d[, ano := y]
  d[, unidade := ifelse(mun %in% RS, "RS", "ES_total")]    # ES_total = todos residentes ES
  obitos_list[[as.character(y)]] <- d[, .(ano, unidade, sexo, banda, mun)]
}
ob <- rbindlist(obitos_list)
# ES = estado inteiro (inclui RS). RS = subconjunto. Duplicar linhas RS para ES:
obES <- copy(ob); obES[, unidade := "ES"]
obRS <- ob[unidade=="RS"]
OB <- rbind(obES[,.(ano,unidade,sexo,banda)], obRS[,.(ano,unidade,sexo,banda)])
OB[, grupo := grupo3(banda)]
saveRDS(OB, "data/obitos.rds")
cat("SIM processado. Total óbitos ES:", nrow(obES), " RS:", nrow(obRS), "\n")
cat("Por ano (ES):\n"); print(obES[,.N,by=ano][order(ano)])
