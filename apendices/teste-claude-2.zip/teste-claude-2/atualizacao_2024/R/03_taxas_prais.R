# ==========================================================================
# 03 - Taxas de mortalidade padronizadas por idade (método direto, padrão 2010)
#      e regressão de Prais-Winsten (APC, IC95%, tendência)  -- método Antunes & Cardoso 2015
# ==========================================================================
suppressMessages({library(data.table); library(prais)})
setwd("/private/tmp/claude-501/-Users-hugocristo-Dropbox---Aulas-2026-1-PPGP-IA-teste-claude-2/1e41a329-d9e0-450d-9f41-9b1ec253ccab/scratchpad")

OB  <- as.data.table(readRDS("data/obitos.rds"))     # ano,unidade(ES/RS),sexo,banda,grupo
POP <- as.data.table(readRDS("data/pop.rds"))        # ano,unidade(ES/RS),sexo,banda,pop,grupo
bandas <- c("15-19","20-24","25-29","30-34","35-39","40-44","45-49",
            "50-54","55-59","60-64","65-69","70-74","75-79","80+")

# grade completa unidade x ano x sexo x banda
grid <- CJ(unidade=c("ES","RS"), ano=1996:2024, sexo=c("M","F"), banda=bandas, unique=TRUE)
D <- OB[, .(obitos=.N), by=.(unidade,ano,sexo,banda)]
tab <- merge(grid, POP[,.(unidade,ano,sexo,banda,pop)], by=c("unidade","ano","sexo","banda"), all.x=TRUE)
tab <- merge(tab, D, by=c("unidade","ano","sexo","banda"), all.x=TRUE)
tab[is.na(obitos), obitos:=0]; tab[is.na(pop), pop:=0]

# população padrão: ES 2010, 15+, por banda (ambos os sexos)
std <- POP[unidade=="ES" & ano==2010, .(Ns=sum(pop)), by=banda]
setkey(std, banda)

# ---- função: taxa padronizada (por 100 mil) p/ subconjunto de bandas e sexo
taxa_pad <- function(dt, bandas_sel, sexo_sel=c("M","F")){
  x <- dt[banda %in% bandas_sel & sexo %in% sexo_sel,
          .(obitos=sum(obitos), pop=sum(pop)), by=banda]
  x <- merge(x, std[banda %in% bandas_sel], by="banda")
  x[pop>0, r := obitos/pop]; x[pop==0, r:=0]
  sum(x$Ns * x$r) / sum(x$Ns) * 1e5
}
grp <- list("15-29"=bandas[1:3], "30-59"=bandas[4:9], "60+"=bandas[10:14])

# ---- série de taxas por unidade x estrato x ano
series <- list(); k <- 1
for(u in c("ES","RS")) for(y in 1996:2024){
  dt <- tab[unidade==u & ano==y]
  add <- function(estr, val){ series[[k]] <<- data.table(unidade=u,estrato=estr,ano=y,taxa=val); k<<-k+1 }
  add("Geral",     taxa_pad(dt, bandas))
  add("Masculino", taxa_pad(dt, bandas, "M"))
  add("Feminino",  taxa_pad(dt, bandas, "F"))
  add("15-29",     taxa_pad(dt, grp[["15-29"]]))
  add("30-59",     taxa_pad(dt, grp[["30-59"]]))
  add("60+",       taxa_pad(dt, grp[["60+"]]))
}
SER <- rbindlist(series)
saveRDS(SER, "data/series_taxas.rds")

# ==========================================================================
# Prais-Winsten -> APC, IC95%, p, tendência   (Y=log10(taxa), X=ano sequencial)
# ==========================================================================
prais_apc <- function(d){
  d <- d[order(ano)]
  # trata taxa=0 (log indefinido): substitui por metade da menor taxa positiva da série
  pos <- d$taxa[d$taxa>0]
  if(length(pos)==0) return(data.table(APC=NA,ic_lo=NA,ic_hi=NA,p=NA,tend="sem casos"))
  d[taxa<=0, taxa := min(pos)/2]
  d[, y := log10(taxa)]; d[, t := ano - min(ano) + 1]
  fit <- tryCatch({
           tmp <- NULL
           invisible(capture.output(
             tmp <- prais_winsten(y ~ t, data=as.data.frame(d), index="ano")))
           tmp
         }, error=function(e) NULL)
  if(is.null(fit)) return(data.table(APC=NA,ic_lo=NA,ic_hi=NA,p=NA,tend="erro"))
  sm <- summary(fit)$coefficients
  b  <- sm["t","Estimate"]; se <- sm["t","Std. Error"]; p <- sm["t","Pr(>|t|)"]
  df <- nrow(d)-2; tc <- qt(0.975, df)
  APC   <- (10^b - 1)*100
  ic_lo <- (10^(b - tc*se) - 1)*100
  ic_hi <- (10^(b + tc*se) - 1)*100
  tend  <- if(is.na(p)) "ND" else if(p<0.05 & b>0) "Crescente" else if(p<0.05 & b<0) "Decrescente" else "Estacionária"
  data.table(APC=round(APC,1), ic_lo=round(ic_lo,2), ic_hi=round(ic_hi,2), p=round(p,3), tend=tend)
}

run_periodo <- function(ano_fim){
  res <- list(); i<-1
  for(u in c("ES","RS")) for(es in c("Geral","Masculino","Feminino","15-29","30-59","60+")){
    d <- SER[unidade==u & estrato==es & ano<=ano_fim]
    r <- prais_apc(copy(d)); r[, `:=`(unidade=u, estrato=es)]
    res[[i]] <- r; i<-i+1
  }
  rbindlist(res)[, .(unidade,estrato,APC,ic_lo,ic_hi,p,tend)]
}

res2020 <- run_periodo(2020)   # validação vs artigo original
res2024 <- run_periodo(2024)   # atualização
saveRDS(list(r2020=res2020, r2024=res2024), "data/prais_result.rds")

cat("\n===== VALIDAÇÃO: período 1996-2020 (comparar c/ Tabela 2 do artigo) =====\n"); print(res2020)
cat("\n===== ATUALIZAÇÃO: período 1996-2024 =====\n"); print(res2024)
