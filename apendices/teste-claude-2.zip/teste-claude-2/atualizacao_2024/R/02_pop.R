# ==========================================================================
# 02 - População IBGE por unidade x ano x sexo x banda etária (>=15)
#   1996-1999: POPBR (DATASUS/IBGE, faixas etárias)
#   2000-2024: POPSVS (SVS/MS-IBGE, idade simples; base pós-Censo 2022)
# ==========================================================================
suppressMessages({library(foreign); library(data.table)})
setwd("/private/tmp/claude-501/-Users-hugocristo-Dropbox---Aulas-2026-1-PPGP-IA-teste-claude-2/1e41a329-d9e0-450d-9f41-9b1ec253ccab/scratchpad")

RS <- c("320010","320030","320140","320170","320190","320334",
        "320450","320455","320460","320503","320506")
bandas <- c("15-19","20-24","25-29","30-34","35-39","40-44","45-49",
            "50-54","55-59","60-64","65-69","70-74","75-79","80+")
banda_de_idade <- function(a){ i <- pmin(pmax(floor((a-15)/5)+1,1),13)
  ifelse(a<15, NA, ifelse(a>=80, "80+", bandas[i])) }
grupo3 <- function(b) ifelse(b %in% c("15-19","20-24","25-29"),"15-29",
                      ifelse(b %in% c("60-64","65-69","70-74","75-79","80+"),"60+","30-59"))

fx_map <- c("1515"="15-19","1616"="15-19","1717"="15-19","1818"="15-19","1919"="15-19",
            "2024"="20-24","2529"="25-29","3034"="30-34","3539"="35-39","4044"="40-44",
            "4549"="45-49","5054"="50-54","5559"="55-59","6064"="60-64","6569"="65-69",
            "7074"="70-74","7579"="75-79","8099"="80+")

pop_list <- list()

## ---- POPBR 1996-1999 --------------------------------------------------
for(y in 1996:1999){
  yy <- sprintf("%02d", y%%100)
  zf <- sprintf("data/POPBR%s.zip", yy)
  if(file.exists(zf)) system(sprintf("cd data && unzip -o POPBR%s.zip >/dev/null 2>&1", yy))
  df <- list.files("data", pattern=sprintf("(?i)POPBR%s\\.dbf$", yy), full.names=TRUE)
  if(!length(df)) { cat("faltando POPBR",yy,"\n"); next }
  d <- as.data.table(read.dbf(df[1], as.is=TRUE))
  setnames(d, toupper(names(d)))
  if("SITUACAO" %in% names(d) && length(unique(d$SITUACAO))>1) d <- d[SITUACAO=="3"] # total
  d[, mun := sprintf("%06s", as.character(MUNIC_RES))]
  d[, banda := fx_map[as.character(FXETARIA)]]
  d[, sexo := ifelse(SEXO=="1","M", ifelse(SEXO=="2","F", NA))]
  d <- d[!is.na(banda) & !is.na(sexo) & substr(mun,1,2)=="32"]
  d[, ano := y]; d[, unidade := ifelse(mun %in% RS, "RS","ES")]
  pop_list[[paste0("br",y)]] <- d[, .(pop=sum(POPULACAO)), by=.(ano,unidade,sexo,banda)]
}

## ---- POPSVS 2000-2024 -------------------------------------------------
for(y in 2000:2024){
  yy <- sprintf("%02d", y%%100)
  zf <- sprintf("data/POPSBR%s.zip", yy)
  if(!file.exists(zf)){ cat("faltando POPSBR",yy,"\n"); next }
  system(sprintf("cd data && unzip -o POPSBR%s.zip >/dev/null 2>&1", yy))
  df <- list.files("data", pattern=sprintf("(?i)^POP%s\\.dbf$", yy), full.names=TRUE)
  d <- as.data.table(read.dbf(df[1], as.is=TRUE))
  setnames(d, toupper(names(d)))
  d[, mun := substr(sprintf("%07s", as.character(COD_MUN)),1,6)]
  d <- d[substr(mun,1,2)=="32"]
  d[, idade := as.integer(IDADE)]
  d[, banda := banda_de_idade(idade)]
  d[, sexo := ifelse(SEXO=="1","M", ifelse(SEXO=="2","F", NA))]
  d <- d[!is.na(banda) & !is.na(sexo)]
  d[, ano := y]; d[, unidade := ifelse(mun %in% RS, "RS","ES")]
  pop_list[[paste0("svs",y)]] <- d[, .(pop=sum(POP)), by=.(ano,unidade,sexo,banda)]
}

POP <- rbindlist(pop_list)
# ES aqui já é "estado inteiro exceto RS" -> preciso ES=estado inteiro (ES+RS)
POP_ES <- POP[, .(pop=sum(pop)), by=.(ano,sexo,banda)][, unidade:="ES"]
POP_RS <- POP[unidade=="RS", .(ano,unidade,sexo,banda,pop)]
POPf <- rbind(POP_ES[,.(ano,unidade,sexo,banda,pop)], POP_RS)
POPf[, grupo := grupo3(banda)]
saveRDS(POPf, "data/pop.rds")
cat("População processada.\n")
cat("ES 15+ por ano (checagem):\n"); print(POPf[unidade=="ES", .(pop=sum(pop)), by=ano][order(ano)])
cat("RS 15+ 2024:", POPf[unidade=="RS"&ano==2024, sum(pop)], "\n")
