let data = null;
let sortCol = 'deaths_per_100k';
let sortAsc = false;
let evoChart = null;
let timelineData = null;
let timelineMunicipios = {};

fetch('../dashboard_data.json')
  .then(r => r.json())
  .then(d => {
    data = d;
    preloadTimeline();
    render();
  })
  .catch(() => {
    document.getElementById('total-cases').textContent = 'Erro ao carregar';
  });

function preloadTimeline() {
  if (data.timeline) {
    timelineData = data.timeline;
  }
}

function render() {
  if (!data) return;
  const { state, municipalities } = data;

  document.getElementById('period').textContent = `${state.period_start} a ${state.period_end}`;
  document.getElementById('total-cases').textContent = state.total_cases.toLocaleString('pt-BR');
  document.getElementById('total-deaths').textContent = state.total_deaths.toLocaleString('pt-BR');
  document.getElementById('death-rate').textContent = state.death_rate + '%';
  document.getElementById('deaths-per-100k').textContent = state.deaths_per_100k;
  document.getElementById('cases-per-100k').textContent = state.cases_per_100k.toLocaleString('pt-BR');
  document.getElementById('population').textContent = state.population.toLocaleString('pt-BR');

  // Populate select
  const sel = document.getElementById('evo-municipio');
  municipalities.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.name;
    opt.textContent = m.name;
    sel.appendChild(opt);
  });

  renderGraficoPerCapita(municipalities);
  renderGraficoLetalidade(municipalities);
  renderGraficoObitos(municipalities);
  renderTabela(municipalities);
  renderEvolucao();
}

function renderGraficoPerCapita(municipalities) {
  const sorted = [...municipalities].filter(m => m.population > 0).sort((a, b) => b.deaths_per_100k - a.deaths_per_100k).slice(0, 10);
  const maxVal = sorted[0].deaths_per_100k;
  const container = document.getElementById('chart-percap');
  container.innerHTML = sorted.map(m => `
    <div class="bar-container">
      <div class="bar-label">
        <span>${m.name}</span>
        <span>${m.deaths_per_100k} /100k</span>
      </div>
      <div class="bar-track">
        <div class="bar-fill purple" style="width: ${(m.deaths_per_100k / maxVal * 100).toFixed(0)}%">
          ${m.deaths} óbitos
        </div>
      </div>
    </div>
  `).join('');
}

function renderGraficoLetalidade(municipalities) {
  const sorted = [...municipalities].filter(m => m.cases > 0).sort((a, b) => b.death_rate - a.death_rate).slice(0, 10);
  const maxRate = sorted[0].death_rate;
  const container = document.getElementById('chart-letalidade');
  container.innerHTML = sorted.map(m => `
    <div class="bar-container">
      <div class="bar-label">
        <span>${m.name}</span>
        <span>${m.death_rate}%</span>
      </div>
      <div class="bar-track">
        <div class="bar-fill blue" style="width: ${(m.death_rate / maxRate * 100).toFixed(0)}%">
          ${m.deaths} óbitos
        </div>
      </div>
    </div>
  `).join('');
}

function renderGraficoObitos(municipalities) {
  const sorted = [...municipalities].sort((a, b) => b.deaths - a.deaths).slice(0, 10);
  const max = sorted[0].deaths;
  const container = document.getElementById('chart-obitos');
  container.innerHTML = sorted.map(m => `
    <div class="bar-container">
      <div class="bar-label">
        <span>${m.name}</span>
        <span>${m.deaths} óbitos</span>
      </div>
      <div class="bar-track">
        <div class="bar-fill red" style="width: ${(m.deaths / max * 100).toFixed(0)}%">
          ${m.deaths}
        </div>
      </div>
    </div>
  `).join('');
}

function renderEvolucao() {
  if (!timelineData) return;
  const canvas = document.getElementById('chart-evolucao');
  const ctx = canvas.getContext('2d');
  const metrica = document.getElementById('evo-metrica').value;
  const munName = document.getElementById('evo-municipio').value;

  // Properly size canvas to display dimensions + HiDPI
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const cssW = rect.width || canvas.parentElement.clientWidth || 800;
  const cssH = 400;
  canvas.width = cssW * dpr;
  canvas.height = cssH * dpr;
  canvas.style.width = cssW + 'px';
  canvas.style.height = cssH + 'px';
  ctx.scale(dpr, dpr);

  const isState = munName === '__state__';

  const timestamps = timelineData.map(d => d.date);
  let series1, series2, label1, label2, color1, color2;

  if (isState) {
    if (metrica === 'cumulative') {
      series1 = timelineData.map(d => d.cases);
      series2 = timelineData.map(d => d.deaths);
      label1 = 'Casos acumulados'; label2 = 'Óbitos acumulados';
      color1 = '#2b6cb0'; color2 = '#e53e3e';
    } else {
      series1 = timelineData.map(d => d.new_cases);
      series2 = timelineData.map(d => d.new_deaths);
      label1 = 'Novos casos/dia'; label2 = 'Novos óbitos/dia';
      color1 = '#2b6cb0'; color2 = '#e53e3e';
    }
  } else {
    ctx.clearRect(0, 0, cssW, cssH);
    ctx.fillStyle = '#666';
    ctx.font = '16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Dados municipais diários disponíveis no dataset original.', cssW/2, cssH/2);
    ctx.fillText('Selecione "Estado (todos)" para ver a série temporal estadual.', cssW/2, cssH/2 + 25);
    return;
  }

  const pad = { top: 30, right: 20, bottom: 50, left: 70 };
  const cw = cssW - pad.left - pad.right;
  const ch = cssH - pad.top - pad.bottom;

  ctx.clearRect(0, 0, cssW, cssH);

  const maxVal = Math.max(...series1, ...series2, 1);
  const n = timestamps.length;
  const step = Math.max(1, Math.floor(n / 12));

  // Background fill
  ctx.fillStyle = '#fafbfc';
  ctx.fillRect(pad.left, pad.top, cw, ch);

  // Grid lines
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = pad.top + (ch * i) / 4;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left + cw, y); ctx.stroke();
  }

  // Y-axis labels
  ctx.fillStyle = '#4a5568';
  ctx.font = '13px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  for (let i = 0; i <= 4; i++) {
    const val = Math.round((maxVal * (4 - i)) / 4);
    const y = pad.top + (ch * i) / 4;
    ctx.fillText(val.toLocaleString('pt-BR'), pad.left - 10, y);
  }

  // X-axis labels
  ctx.fillStyle = '#4a5568';
  ctx.font = '12px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  for (let i = 0; i < n; i += step) {
    const x = pad.left + (cw * i) / (n - 1);
    const parts = timestamps[i].split('-');
    ctx.fillText(`${parts[1]}/${parts[2]}`, x, cssH - pad.bottom + 8);
  }
  ctx.textBaseline = 'alphabetic';

  function drawLine(data, color, fillColor) {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    for (let i = 0; i < n; i++) {
      const x = pad.left + (cw * i) / (n - 1);
      const y = pad.top + ch - (data[i] / maxVal) * ch;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();

    if (fillColor) {
      const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ch);
      grad.addColorStop(0, fillColor);
      grad.addColorStop(1, fillColor.replace('0.12', '0.01'));
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(pad.left, pad.top + ch);
      for (let i = 0; i < n; i++) {
        const x = pad.left + (cw * i) / (n - 1);
        const y = pad.top + ch - (data[i] / maxVal) * ch;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(pad.left + cw, pad.top + ch);
      ctx.closePath();
      ctx.fill();
    }
  }

  drawLine(series1, color1, color1.replace(')', ', 0.12)').replace('rgb', 'rgba'));
  drawLine(series2, color2, color2.replace(')', ', 0.12)').replace('rgb', 'rgba'));

  // Legend box
  const lx = pad.left + 12;
  const ly = pad.top + 12;
  ctx.fillStyle = 'rgba(255,255,255,0.92)';
  ctx.fillRect(lx - 6, ly - 4, 200, 48);
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.strokeRect(lx - 6, ly - 4, 200, 48);

  ctx.font = '13px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = color1;
  ctx.fillRect(lx, ly + 6, 18, 3);
  ctx.fillStyle = '#2d3748';
  ctx.fillText(label1, lx + 26, ly + 7);
  ctx.fillStyle = color2;
  ctx.fillRect(lx, ly + 24, 18, 3);
  ctx.fillStyle = '#2d3748';
  ctx.fillText(label2, lx + 26, ly + 25);

  // Y-axis title
  ctx.save();
  ctx.translate(18, pad.top + ch / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#718096';
  ctx.font = '12px "Segoe UI", Arial, sans-serif';
  ctx.fillText(metrica === 'cumulative' ? 'Valor acumulado' : 'Valor diário', 0, 0);
  ctx.restore();

  // X-axis title
  ctx.fillStyle = '#718096';
  ctx.font = '12px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  ctx.fillText('Data (mês/dia)', cssW / 2, cssH - 6);
  ctx.textBaseline = 'alphabetic';
}

function mudarMunicipioEvolucao() {
  renderEvolucao();
}

let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (data) renderEvolucao(); }, 250);
});

function renderTabela(municipalities) {
  const filtro = (document.getElementById('filtro').value || '').toLowerCase();
  const filtered = municipalities.filter(m => m.name.toLowerCase().includes(filtro));
  const sorted = [...filtered].sort((a, b) => {
    let va = a[sortCol], vb = b[sortCol];
    if (typeof va === 'string') return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    return sortAsc ? va - vb : vb - va;
  });

  const tbody = document.getElementById('tabela-body');
  tbody.innerHTML = sorted.map(m => `
    <tr>
      <td>${m.name}</td>
      <td>${m.population.toLocaleString('pt-BR')}</td>
      <td>${m.cases.toLocaleString('pt-BR')}</td>
      <td>${m.deaths.toLocaleString('pt-BR')}</td>
      <td>${m.death_rate}%</td>
      <td>${m.deaths_per_100k}</td>
      <td>${m.cases_per_100k.toLocaleString('pt-BR')}</td>
    </tr>
  `).join('');
}

function filtrarTabela() {
  if (data) renderTabela(data.municipalities);
}

function ordenarPor(col) {
  if (sortCol === col) sortAsc = !sortAsc;
  else { sortCol = col; sortAsc = false; }
  document.querySelectorAll('th').forEach(th => th.classList.remove('asc', 'desc'));
  const el = document.querySelector(`th[data-col="${col}"]`);
  if (el) el.classList.add(sortAsc ? 'asc' : 'desc');
  if (data) renderTabela(data.municipalities);
}

function ordenarTabela() {
  const val = document.getElementById('sort-select').value;
  sortCol = val;
  sortAsc = false;
  document.querySelectorAll('th').forEach(th => th.classList.remove('asc', 'desc'));
  if (data) renderTabela(data.municipalities);
}
