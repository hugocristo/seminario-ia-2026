# Pesquisa Covid-19 — Protocolo de Reprodutibilidade

## Definições do agente

Aja como um pesquisador de saúde pública avaliando dados sobre a pandemia de Covid-19 no Estado do Espírito Santo - ES (Brasil). Utilize vocabulário técnico, texto conciso e objetivo, porém acessível ao público leigo. Sempre indique suas fontes e opte por explicações visuais para defender seus argumentos. Nas situações em que houver dúvidas, busque mais fontes na Web (sempre artigos científicos, documentos portais governamentais oficiais) para fortalecer as inferências.

## Objetivos da pesquisa

Quantificar a proporção de óbitos por municípios no ES.

## Pré-requisitos

- **Python 3.14+** com pacotes: `pandas`, `openpyxl`, `requests`
- Instalação: `pip install pandas openpyxl requests`
- Arquivo de dados: `covid-es.xlsx` (contém planilha única com colunas: `date`, `state`, `name`, `code`, `cases`, `deaths`)

## Procedimentos executados

### 1. Análise exploratória dos dados

**Script**: `analise_inicial.py`

```python
import pandas as pd
df = pd.read_excel('covid-es.xlsx')
print(f'Municípios: {df["name"].nunique()}')
print(f'Período: {df["date"].min()} a {df["date"].max()}')
latest = df[df['date'] == df['date'].max()]
latest['death_rate'] = (latest['deaths'] / latest['cases'] * 100).round(2)
```

**Ações**:
1. Carregar `covid-es.xlsx` com `pandas.read_excel()`
2. Identificar estrutura: 14.742 linhas, 6 colunas (`date`, `state`, `name`, `code`, `cases`, `deaths`)
3. Agrupar por município (78 municípios, 78 códigos IBGE distintos)
4. Filtrar snapshot mais recente (01/10/2020)
5. Calcular `death_rate = (deaths / cases) * 100`
6. Salvar resultado em `municipios_es.csv` para reuso

**Resultados intermediários salvos em**: `municipios_es.csv`

### 2. Coleta de dados sociodemográficos

**Fontes consultadas**:

| Fonte | URL | Dados obtidos |
|-------|-----|---------------|
| IBGE — Cidades e Estados | https://www.ibge.gov.br/cidades-e-estados/es/.html | População (Censo 2022: 3.833.712), área (46.074 km²), densidade (83,21 hab/km²), IDH (0,771), renda per capita (R$ 2.249) |
| IBGE — Cidades@ (Vitória) | https://www.ibge.gov.br/cidades-e-estados/es/vitoria.html | Exemplo de indicador municipal: IDHM (0,845), escolarização (99,24%), mortalidade infantil (10,73/1000) |
| IBGE — SIDRA API (Tabela 4714) | https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022 | População residente por município (Censo 2022) — sucesso na segunda tentativa |
| IJSN — Painéis Interativos | https://ijsn.es.gov.br/paineis-interativos | Lista de painéis com indicadores socioeconômicos (PIB municipal, IDRS, ODS, Censo 2022) |
| IJSN — Observatório COVID-19 | https://ijsn.es.gov.br/observatorios/observatorio-covid-19 | Indicadores semanais em PDF (2020-2022) e notas técnicas |

**Script auxiliar**: `busca_dados_ibge.py` (tentativa inicial com API de Agregados, sem sucesso)

### 3. Coleta de dados populacionais por município (Censo 2022)

**Script**: `buscar_populacao.py`

```python
import requests
url = 'https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022'
r = requests.get(url, timeout=120)
data = r.json()
# Filtra municípios do ES (código iniciado em '32') e salva CSV
```

**Ações**:
- Consultar API SIDRA clássica do IBGE (tabela 4714, variável 93 — população residente)
- Filtrar 78 municípios do ES (códigos IBGE iniciados em `32`)
- Mapear por nome do município (correção manual: `Atílio Vivacqua` → `Atílio Vivácqua`)
- Salvar em `populacao_es.csv`

**Resultado**: `populacao_es.csv` (78 municípios, população do Censo 2022)

### 4. Geração do relatório Markdown + dados do painel

**Script**: `gerar_relatorio.py`

```python
import pandas as pd, numpy as np, json, csv

# Carrega dados COVID e população
df = pd.read_excel('covid-es.xlsx')
pop_map = {row['nome']: int(row['populacao']) for row in csv.DictReader(open('populacao_es.csv'))}

# Snapshot final + série temporal
latest = df[df['date'] == df['date'].max()]
timeline = df.groupby('date')[['cases', 'deaths']].sum()

# Métricas: letalidade, óbitos/100k hab, casos/100k hab
latest['death_rate'] = (latest['deaths'] / latest['cases'] * 100).round(2)
latest['deaths_per_100k'] = (latest['deaths'] / latest['population'] * 100000).round(2)
latest['cases_per_100k'] = (latest['cases'] / latest['population'] * 100000).round(2)

# Modelo de evolução: regressão polinomial grau 3 sobre casos acumulados
coeffs = np.polyfit(np.arange(len(timeline)), timeline['cases'].values, 3)
r2 = 1 - (np.sum((y - p(x))**2) / np.sum((y - y.mean())**2))

# Gera relatorio.md e dashboard_data.json
```

**Ações**:
1. Carregar `populacao_es.csv` e mapear nome → população
2. Calcular métricas: letalidade (%), óbitos/100k hab, casos/100k hab
3. Construir série temporal estadual (casos e óbitos acumulados e novos/dia)
4. Ajustar regressão polinomial grau 3 sobre curva de casos acumulados (R² ≈ 0,998)
5. Estimar taxa de crescimento diário ao final do período
6. Gerar tabelas: top 10 óbitos absolutos, mortalidade per capita, letalidade
7. Exportar `dashboard_data.json` com estrutura expandida

**Resultados**: `relatorio.md` (~160 linhas) e `dashboard_data.json` (com `timeline[]`)

**Estrutura do JSON de saída** (`dashboard_data.json`):
```json
{
  "state": { "name", "code", "total_cases", "total_deaths", "death_rate",
             "deaths_per_100k", "cases_per_100k", "population",
             "period_start", "period_end" },
  "timeline": [ { "date", "cases", "deaths", "new_cases", "new_deaths" }, ... ],
  "municipalities": [ { "name", "code", "cases", "deaths", "death_rate",
                        "population", "deaths_per_100k", "cases_per_100k" }, ... ]
}
```

### 5. Criação do painel interativo (v2)

**Arquivos em `./painel/`**:

| Arquivo | Função |
|---------|--------|
| `index.html` | 6 cards de resumo, evolução temporal (canvas), 3 gráficos de barras, tabela com 7 colunas |
| `style.css` | Estilos responsivos; nova cor roxa para métrica per capita |
| `dashboard.js` | Fetch do JSON, gráfico canvas de evolução (acumulado/novos por dia), TOP 10 per capita |

**Funcionalidades do painel**:
- Cards: Casos, Óbitos, Letalidade (%), **Óbitos/100k hab**, **Casos/100k hab**, **População**
- **Evolução temporal** (canvas): alterna entre acumulado e novos por dia; seletor de município
- **TOP 10 por mortalidade per capita** (novo gráfico roxo)
- TOP 10 por letalidade
- TOP 10 por óbitos absolutos
- Tabela com 7 colunas: Município, População, Casos, Óbitos, Letalidade%, **Óbitos/100k**, **Casos/100k** (ordenável e filtrável)
- Fontes atualizadas

**Para executar localmente**:
```bash
python -m http.server
# Acessar: http://localhost:8000/painel/index.html
```

## Fluxo completo de reprodução

```bash
# 1. Instalar dependências
pip install pandas openpyxl requests numpy

# 2. Análise exploratória
python analise_inicial.py

# 3. Obter população por município (IBGE SIDRA API)
python buscar_populacao.py

# 4. Gerar relatório e dados do painel
python gerar_relatorio.py

# 5. Servir o painel localmente
python -m http.server
# Abrir http://localhost:8000/painel/index.html
```

## Principais resultados

| Indicador | Valor |
|-----------|-------|
| Período analisado | 27/03/2020 a 01/10/2020 |
| População do ES (Censo 2022) | 3.833.712 |
| Total de casos no ES | 1.311.590 |
| Total de óbitos no ES | 3.524 |
| Taxa de letalidade geral | 0,27% |
| Mortalidade (óbitos/100k hab) | 91,92 |
| Incidência (casos/100k hab) | 34.212 |
| Pico de novos casos | 21.410 (07/07/2020) |
| Pico de novos óbitos | 63 (23/06/2020) |
| Maior mortalidade per capita | Alto Rio Novo (147,97/100k) |
| Maior taxa de letalidade | Alto Rio Novo (0,62%) |
| Município sem óbitos | Iconha (4.890 casos, 0 óbitos) |
| R² modelo polinomial | 0,998 |

## Fontes

1. **Dataset COVID-19 ES**: `covid-es.xlsx`
2. **IBGE — SIDRA API (Tabela 4714)**: https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022
3. **IBGE — Cidades e Estados**: https://www.ibge.gov.br/cidades-e-estados/es/.html
4. **IBGE — Censo 2022**: https://censo2022.ibge.gov.br/
5. **IJSN — Observatório COVID-19**: https://ijsn.es.gov.br/observatorios/observatorio-covid-19
6. **IJSN — Painéis Interativos**: https://ijsn.es.gov.br/paineis-interativos
7. **PNUD — IDH**: https://www.br.undp.org/
8. **DATASUS**: https://datasus.saude.gov.br/ 

