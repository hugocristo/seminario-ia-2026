import sys
import requests
import json

sys.stdout.reconfigure(encoding='utf-8')

# Load municipality codes
import pandas as pd
df_mun = pd.read_csv('municipios_es.csv', encoding='utf-8')
codes = df_mun['code'].tolist()
print(f'Total municipalities: {len(codes)}')

# IBGE API: Get population data for each municipality
# Agregado 6579 - População estimada
try:
    url = 'https://servicodados.ibge.gov.br/api/v3/agregados/6579/variaveis'
    r = requests.get(url, timeout=15)
    if r.status_code == 200:
        data = r.json()
        print('Population variables:')
        for v in data:
            print(f"  {v['id']}: {v['nome']}")
except Exception as e:
    print(f'Error: {e}')

# Try to get latest population data (2024 estimates) - agregado 6579
# Use localidades N6 (municípios) with filter for ES (32)
try:
    # Get population estimate 2024 for all ES municipalities
    url = 'https://servicodados.ibge.gov.br/api/v3/agregados/6579/periodos/2024/variaveis/9324?localidades=N6[3200001..3205300]'
    r = requests.get(url, timeout=15)
    print(f'\nPopulation 2024 status: {r.status_code}')
    if r.status_code == 200:
        data = r.json()
        print(json.dumps(data, indent=2, ensure_ascii=False)[:2000])
except Exception as e:
    print(f'Error: {e}')

# IBGE Cidades API - per municipality info
try:
    # Get data for Vitória (3205300) as test
    url = 'https://servicodados.ibge.gov.br/api/v1/localidades/municipios/3205300'
    r = requests.get(url, timeout=15)
    print(f'\nVitória info status: {r.status_code}')
    if r.status_code == 200:
        data = r.json()
        print(json.dumps(data, indent=2, ensure_ascii=False)[:1500])
except Exception as e:
    print(f'Error: {e}')

# Alternative: Get IBGE census data per municipality via SIDRA
try:
    # Tabela 9514 - População residente por sexo e idade (Censo 2022) - ES
    url = 'https://servicodados.ibge.gov.br/api/v3/agregados/9514/variaveis'
    r = requests.get(url, timeout=15)
    print(f'\nCenso 2022 variables status: {r.status_code}')
    if r.status_code == 200:
        data = r.json()
        print('Censo 2022 variables:')
        for v in data:
            print(f"  {v['id']}: {v['nome']}")
except Exception as e:
    print(f'Error: {e}')
