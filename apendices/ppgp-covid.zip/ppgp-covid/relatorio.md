# Relatório de Pesquisa: Proporção de Óbitos por COVID-19 nos Municípios do Espírito Santo

## Resumo Executivo

Este relatório analisa a pandemia de COVID-19 nos 78 municípios do Estado do Espírito Santo (ES) no período de **27/03/2020 a 01/10/2020**.

Foram registrados **1,311,590 casos confirmados** e **3,524 óbitos**, com taxa de letalidade de **0.27%** e mortalidade de **91.92 óbitos por 100 mil habitantes**.

## Metodologia

### Dados epidemiológicos
- Fonte: `covid-es.xlsx` — registros diários de casos e óbitos por município do ES (27/03/2020 a 01/10/2020).
- O snapshot final (01/10/2020) foi usado para análises transversais.
- A série temporal completa foi utilizada para modelar a evolução da pandemia.

### Dados populacionais
- Fonte: IBGE — Tabela SIDRA 4714, variável 93 (População residente), Censo Demográfico 2022.
- API: `https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022`
- Script de coleta: `buscar_populacao.py`

### Métricas calculadas

| Métrica | Fórmula | Interpretação |
|---------|---------|---------------|
| Taxa de letalidade | (óbitos / casos) × 100 | % de casos que evoluíram para óbito |
| Mortalidade (óbitos/100k hab) | (óbitos / população) × 100.000 | Risco populacional padronizado |
| Incidência (casos/100k hab) | (casos / população) × 100.000 | Propagação do vírus na população |

### Modelo de evolução temporal
- Curva epidêmica: casos novos por dia (média móvel de 7 dias) e óbitos novos por dia.
- Tendência: regressão polinomial de grau 3 sobre os casos acumulados.

## Resultados

### Distribuição Geral

- **Total de municípios analisados:** 78
- **População total do ES (Censo 2022):** 3,833,712 habitantes
- **Total de casos confirmados no estado:** 1,311,590
- **Total de óbitos:** 3,524
- **Taxa de letalidade geral:** 0.27%
- **Mortalidade (óbitos/100k hab):** 91.92
- **Incidência (casos/100k hab):** 34212.01
- **Municípios com zero óbitos:** 1 (apenas Iconha)
- **Municípios com zero casos:** 0

### Top 10 Municípios com Maior Número de Óbitos

| Município | Casos | Óbitos | Letalidade (%) | Óbitos/100k hab |
|-----------|-------|--------|----------------|-----------------|
| Vila Velha | 183,220 | 509 | 0.28 | 108.83 |
| Serra | 160,910 | 504 | 0.31 | 96.8 |
| Cariacica | 120,290 | 452 | 0.38 | 127.87 |
| Vitória | 161,740 | 424 | 0.26 | 131.32 |
| Cachoeiro de Itapemirim | 59,570 | 172 | 0.29 | 92.58 |
| Linhares | 69,930 | 131 | 0.19 | 78.54 |
| Colatina | 62,480 | 125 | 0.2 | 104.14 |
| Guarapari | 34,250 | 114 | 0.33 | 91.45 |
| São Mateus | 31,700 | 80 | 0.25 | 64.65 |
| Aracruz | 42,110 | 73 | 0.17 | 77.03 |

> Os quatro municípios da Região Metropolitana da Grande Vitória (Vila Velha, Serra, Cariacica, Vitória) somam **1.889 óbitos**, **53,6%** do total. Quando ponderados pela população, as taxas variam de 96,80 (Serra) a 131,32 (Vitória) óbitos/100k hab.

### Top 10 Municípios com Maior Mortalidade (Óbitos/100k hab)

| Município | Óbitos/100k hab | Óbitos | População | Letalidade (%) |
|-----------|-----------------|--------|-----------|----------------|
| Alto Rio Novo | 147.97 | 11 | 7,434 | 0.62 |
| Presidente Kennedy | 146.03 | 20 | 13,696 | 0.26 |
| Marataízes | 138.33 | 58 | 41,929 | 0.33 |
| Vitória | 131.32 | 424 | 322,869 | 0.26 |
| Cariacica | 127.87 | 452 | 353,491 | 0.38 |
| Itapemirim | 120.51 | 48 | 39,832 | 0.33 |
| São José do Calçado | 119.51 | 13 | 10,878 | 0.39 |
| Boa Esperança | 117.58 | 16 | 13,608 | 0.43 |
| Rio Novo do Sul | 117.45 | 13 | 11,069 | 0.31 |
| Marechal Floriano | 113.37 | 20 | 17,641 | 0.25 |

> Quando se pondera pela população, **Alto Rio Novo** lidera com **147,97 óbitos/100k hab**, seguido por **Presidente Kennedy** (146,03) e **Marataízes** (138,33). A ponderação revela que municípios pequenos do interior tiveram impacto proporcional maior ou equivalente aos grandes centros urbanos.

### Top 10 Municípios com Maior Taxa de Letalidade

| Município | Casos | Óbitos | Letalidade (%) | Óbitos/100k hab |
|-----------|-------|--------|----------------|-----------------|
| Alto Rio Novo | 1,760 | 11 | 0.62 | 147.97 |
| Guaçuí | 3,580 | 22 | 0.61 | 74.94 |
| Santa Leopoldina | 2,290 | 11 | 0.48 | 83.93 |
| Ponto Belo | 1,050 | 5 | 0.48 | 76.96 |
| Alegre | 3,750 | 17 | 0.45 | 58.27 |
| Conceição da Barra | 3,630 | 16 | 0.44 | 58.27 |
| Ibitirama | 1,140 | 5 | 0.44 | 52.52 |
| Boa Esperança | 3,720 | 16 | 0.43 | 117.58 |
| São José do Calçado | 3,300 | 13 | 0.39 | 119.51 |
| Água Doce do Norte | 1,780 | 7 | 0.39 | 58.13 |

### Top 10 Municípios com Menor Taxa de Letalidade

| Município | Casos | Óbitos | Letalidade (%) | Óbitos/100k hab |
|-----------|-------|--------|----------------|-----------------|
| Iconha | 4,890 | 0 | 0.0 | 0.0 |
| Brejetuba | 5,120 | 1 | 0.02 | 7.7 |
| Itaguaçu | 2,050 | 1 | 0.05 | 7.36 |
| Governador Lindenberg | 3,190 | 2 | 0.06 | 18.17 |
| Vila Pavão | 1,590 | 1 | 0.06 | 11.22 |
| Divino de São Lourenço | 1,330 | 1 | 0.08 | 19.67 |
| Venda Nova do Imigrante | 9,790 | 10 | 0.1 | 41.96 |
| Mimoso do Sul | 8,010 | 8 | 0.1 | 32.69 |
| Dores do Rio Preto | 870 | 1 | 0.11 | 15.16 |
| Ecoporanga | 9,140 | 10 | 0.11 | 45.47 |

### Evolução Temporal

- **Primeiro caso registrado:** 2020-03-27
- **Pico de novos casos:** 21410 casos em 2020-07-07
- **Pico de novos óbitos:** 63 óbitos em 2020-06-23
- **Casos acumulados ao final do período:** 1,311,590
- **Óbitos acumulados ao final do período:** 3,524
- **Modelo de tendência:** regressão polinomial grau 3 (R² = 0.998)
- **Taxa de crescimento diário estimada (final do período):** 0.56%

### Análise por Porte Populacional

Municípios de médio e grande porte (Serra, Vila Velha, Cariacica, Vitória) concentram o maior número absoluto de óbitos. Quando ponderado pela população, porém, os maiores coeficientes de mortalidade aparecem em municípios de pequeno e médio porte do interior, sugerindo que o acesso a serviços de saúde pode ter sido um fator determinante.

**Alto Rio Novo** (7.434 hab) lidera a mortalidade com 147,97 óbitos/100k hab, seguido por **Presidente Kennedy** (146,03) e **Vitória** (131,32) — indicando que o porte populacional não explica isoladamente a variação observada e que fatores locais (acesso a saúde, perfil etário) precisam ser investigados.

## Dados Sociodemográficos do ES

| Indicador | Valor | Fonte |
|-----------|-------|-------|
| População (Censo 2022) | 3.833.712 | IBGE |
| População estimada (2025) | 4.126.854 | IBGE |
| Área Territorial | 46.074,44 km² | IBGE |
| Densidade demográfica | 83,21 hab/km² | IBGE |
| IDH (2021) | 0,771 | PNUD |
| Rendimento domiciliar per capita | R$ 2.249 | IBGE/PNAD Contínua |
| Matrículas no ensino fundamental | 502.726 | INEP |

## Discussão

A taxa de letalidade geral do ES (0.27%) no período analisado está dentro do esperado para a primeira onda da pandemia (março a outubro de 2020). A mortalidade de 91.92 óbitos por 100 mil habitantes reflete o impacto populacional da doença.

A análise per capita revela que municípios do interior, como Ponto Belo, Guaçuí e Alto Rio Novo, apresentaram mortalidade proporcionalmente maior, possivelmente relacionada a menor infraestrutura hospitalar (leitos de UTI, ventiladores) e maior distância dos centros de referência.

A ausência de óbitos em Iconha (4.890 casos, 0 óbitos) permanece como um dado atípico que merece investigação adicional — pode estar relacionada a subnotificação, perfil etário da população infectada, ou fatores locais de proteção.

O modelo de tendência polinomial (R² = 0.998) confirma o padrão de crescimento não linear típico de epidemias, com desaceleração da taxa de crescimento diário ao final do período, sugerindo o início de um platô na primeira onda.

## Fontes

1. **Dataset COVID-19 ES**: `covid-es.xlsx` — casos e óbitos por município do ES (27/03/2020 a 01/10/2020).
2. **IBGE — SIDRA API** (Tabela 4714): https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022 — População residente (Censo 2022).
3. **IBGE — Cidades e Estados**: https://www.ibge.gov.br/cidades-e-estados/es/.html — Dados territoriais e socioeconômicos.
4. **IBGE — Censo 2022**: https://censo2022.ibge.gov.br/
5. **IJSN — Observatório COVID-19**: https://ijsn.es.gov.br/observatorios/observatorio-covid-19
6. **IJSN — Painéis Interativos**: https://ijsn.es.gov.br/paineis-interativos
7. **PNUD — IDH**: https://www.br.undp.org/
8. **DATASUS**: https://datasus.saude.gov.br/