import sys
import json
import csv
import pandas as pd
import numpy as np

sys.stdout.reconfigure(encoding='utf-8')

# Load population data and build name -> population map
pop_map = {}
with open('populacao_es.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        pop_map[row['nome']] = int(row['populacao'])

# Manual name corrections for mismatches between datasets
NAME_CORRECTIONS = {
    'Atílio Vivacqua': 'Atílio Vivácqua',
}

df = pd.read_excel('covid-es.xlsx')
latest_date = df['date'].max()
latest = df[df['date'] == latest_date].copy()

# Build state-level daily timeline
timeline = df.groupby('date')[['cases', 'deaths']].sum().reset_index()
timeline['date'] = timeline['date'].dt.strftime('%Y-%m-%d')
timeline['new_cases'] = timeline['cases'].diff().fillna(timeline['cases'])
timeline['new_deaths'] = timeline['deaths'].diff().fillna(timeline['deaths'])
timeline['new_cases'] = timeline['new_cases'].clip(0)
timeline['new_deaths'] = timeline['new_deaths'].clip(0)
timeline_list = timeline.to_dict('records')

latest['death_rate'] = (latest['deaths'] / latest['cases'] * 100).round(2)
latest['death_rate'] = latest['death_rate'].fillna(0)

# Map population
latest['population'] = latest['name'].map(pop_map)
# Try fallback with corrected names
missing_mask = latest['population'].isna()
if missing_mask.any():
    for idx in latest[missing_mask].index:
        corrected = NAME_CORRECTIONS.get(latest.at[idx, 'name'])
        if corrected and corrected in pop_map:
            latest.at[idx, 'population'] = pop_map[corrected]
        else:
            print(f'Warning: population not found for: {latest.at[idx, "name"]}')
            latest.at[idx, 'population'] = 0
latest['population'] = latest['population'].astype(int)

latest['population'] = latest['population'].astype(int)
latest['deaths_per_100k'] = (latest['deaths'] / latest['population'] * 100000).round(2)
latest['cases_per_100k'] = (latest['cases'] / latest['population'] * 100000).round(2)

total_cases = latest['cases'].sum()
total_deaths = latest['deaths'].sum()
overall_rate = round(total_deaths / total_cases * 100, 2)
state_pop = latest['population'].sum()
overall_deaths_per_100k = round(total_deaths / state_pop * 100000, 2)
overall_cases_per_100k = round(total_cases / state_pop * 100000, 2)

top_deaths = latest.sort_values('deaths', ascending=False).head(10)
top_rate = latest[latest['cases'] > 0].sort_values('death_rate', ascending=False).head(10)
bottom_rate = latest[latest['cases'] > 0].sort_values('death_rate', ascending=True).head(10)

# --- Generate markdown ---
lines = []
lines.append('# Relatório de Pesquisa: Proporção de Óbitos por COVID-19 nos Municípios do Espírito Santo')
lines.append('')
lines.append('## Resumo Executivo')
lines.append('')
lines.append(f'Este relatório analisa a pandemia de COVID-19 nos 78 municípios do Estado do Espírito Santo (ES) no período de **{df["date"].min().strftime("%d/%m/%Y")} a {latest_date.strftime("%d/%m/%Y")}**.')
lines.append('')
lines.append(f'Foram registrados **{total_cases:,} casos confirmados** e **{total_deaths:,} óbitos**, com taxa de letalidade de **{overall_rate}%** e mortalidade de **{overall_deaths_per_100k} óbitos por 100 mil habitantes**.')
lines.append('')
lines.append('## Metodologia')
lines.append('')
lines.append('### Dados epidemiológicos')
lines.append('- Fonte: `covid-es.xlsx` — registros diários de casos e óbitos por município do ES (27/03/2020 a 01/10/2020).')
lines.append('- O snapshot final (01/10/2020) foi usado para análises transversais.')
lines.append('- A série temporal completa foi utilizada para modelar a evolução da pandemia.')
lines.append('')
lines.append('### Dados populacionais')
lines.append('- Fonte: IBGE — Tabela SIDRA 4714, variável 93 (População residente), Censo Demográfico 2022.')
lines.append('- API: `https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022`')
lines.append('- Script de coleta: `buscar_populacao.py`')
lines.append('')
lines.append('### Métricas calculadas')
lines.append('')
lines.append('| Métrica | Fórmula | Interpretação |')
lines.append('|---------|---------|---------------|')
lines.append('| Taxa de letalidade | (óbitos / casos) × 100 | % de casos que evoluíram para óbito |')
lines.append('| Mortalidade (óbitos/100k hab) | (óbitos / população) × 100.000 | Risco populacional padronizado |')
lines.append('| Incidência (casos/100k hab) | (casos / população) × 100.000 | Propagação do vírus na população |')
lines.append('')
lines.append('### Modelo de evolução temporal')
lines.append('- Curva epidêmica: casos novos por dia (média móvel de 7 dias) e óbitos novos por dia.')
lines.append('- Tendência: regressão polinomial de grau 3 sobre os casos acumulados.')
lines.append('')
lines.append('## Resultados')
lines.append('')
lines.append('### Distribuição Geral')
lines.append('')
lines.append(f'- **Total de municípios analisados:** 78')
lines.append(f'- **População total do ES (Censo 2022):** {state_pop:,} habitantes')
lines.append(f'- **Total de casos confirmados no estado:** {total_cases:,}')
lines.append(f'- **Total de óbitos:** {total_deaths:,}')
lines.append(f'- **Taxa de letalidade geral:** {overall_rate}%')
lines.append(f'- **Mortalidade (óbitos/100k hab):** {overall_deaths_per_100k}')
lines.append(f'- **Incidência (casos/100k hab):** {overall_cases_per_100k}')
lines.append(f'- **Municípios com zero óbitos:** {len(latest[latest["deaths"] == 0])} (apenas Iconha)')
lines.append(f'- **Municípios com zero casos:** {len(latest[latest["cases"] == 0])}')
lines.append('')
lines.append('### Top 10 Municípios com Maior Número de Óbitos')
lines.append('')
lines.append('| Município | Casos | Óbitos | Letalidade (%) | Óbitos/100k hab |')
lines.append('|-----------|-------|--------|----------------|-----------------|')
for _, row in top_deaths.iterrows():
    lines.append(f'| {row["name"]} | {row["cases"]:,} | {row["deaths"]} | {row["death_rate"]} | {row["deaths_per_100k"]} |')
lines.append('')
lines.append('> Os quatro municípios da Região Metropolitana da Grande Vitória (Vila Velha, Serra, Cariacica, Vitória) somam **1.889 óbitos**, **53,6%** do total. Quando ponderados pela população, as taxas variam de 96,80 (Serra) a 131,32 (Vitória) óbitos/100k hab.')
lines.append('')

# Top 10 óbitos per capita
top_percap = latest.sort_values('deaths_per_100k', ascending=False).head(10)
lines.append('### Top 10 Municípios com Maior Mortalidade (Óbitos/100k hab)')
lines.append('')
lines.append('| Município | Óbitos/100k hab | Óbitos | População | Letalidade (%) |')
lines.append('|-----------|-----------------|--------|-----------|----------------|')
for _, row in top_percap.iterrows():
    lines.append(f'| {row["name"]} | {row["deaths_per_100k"]} | {row["deaths"]} | {row["population"]:,} | {row["death_rate"]} |')
lines.append('')
lines.append('> Quando se pondera pela população, **Alto Rio Novo** lidera com **147,97 óbitos/100k hab**, seguido por **Presidente Kennedy** (146,03) e **Marataízes** (138,33). A ponderação revela que municípios pequenos do interior tiveram impacto proporcional maior ou equivalente aos grandes centros urbanos.')
lines.append('')

lines.append('### Top 10 Municípios com Maior Taxa de Letalidade')
lines.append('')
lines.append('| Município | Casos | Óbitos | Letalidade (%) | Óbitos/100k hab |')
lines.append('|-----------|-------|--------|----------------|-----------------|')
for _, row in top_rate.iterrows():
    lines.append(f'| {row["name"]} | {row["cases"]:,} | {row["deaths"]} | {row["death_rate"]} | {row["deaths_per_100k"]} |')
lines.append('')
lines.append('### Top 10 Municípios com Menor Taxa de Letalidade')
lines.append('')
lines.append('| Município | Casos | Óbitos | Letalidade (%) | Óbitos/100k hab |')
lines.append('|-----------|-------|--------|----------------|-----------------|')
for _, row in bottom_rate.iterrows():
    lines.append(f'| {row["name"]} | {row["cases"]:,} | {row["deaths"]} | {row["death_rate"]} | {row["deaths_per_100k"]} |')
lines.append('')

# Evolution timeline summary
lines.append('### Evolução Temporal')
lines.append('')
tl = timeline
peak_cases = tl.loc[tl['new_cases'].idxmax()]
peak_deaths = tl.loc[tl['new_deaths'].idxmax()]
lines.append(f'- **Primeiro caso registrado:** {tl["date"].iloc[0]}')
lines.append(f'- **Pico de novos casos:** {peak_cases["new_cases"]:.0f} casos em {peak_cases["date"]}')
lines.append(f'- **Pico de novos óbitos:** {peak_deaths["new_deaths"]:.0f} óbitos em {peak_deaths["date"]}')
lines.append(f'- **Casos acumulados ao final do período:** {int(tl["cases"].iloc[-1]):,}')
lines.append(f'- **Óbitos acumulados ao final do período:** {int(tl["deaths"].iloc[-1]):,}')

# Polynomial trend model
x = np.arange(len(tl))
y = tl['cases'].values
coeffs = np.polyfit(x, y, 3)
p = np.poly1d(coeffs)
r2 = 1 - (np.sum((y - p(x))**2) / np.sum((y - y.mean())**2))
growth_daily = (y[-1] / y[-8])**(1/7) - 1 if y[-8] > 0 else 0
lines.append(f'- **Modelo de tendência:** regressão polinomial grau 3 (R² = {r2:.3f})')
lines.append(f'- **Taxa de crescimento diário estimada (final do período):** {growth_daily*100:.2f}%')
lines.append('')
lines.append('### Análise por Porte Populacional')
lines.append('')
lines.append('Municípios de médio e grande porte (Serra, Vila Velha, Cariacica, Vitória) concentram o maior número absoluto de óbitos. Quando ponderado pela população, porém, os maiores coeficientes de mortalidade aparecem em municípios de pequeno e médio porte do interior, sugerindo que o acesso a serviços de saúde pode ter sido um fator determinante.')
lines.append('')
lines.append('**Alto Rio Novo** (7.434 hab) lidera a mortalidade com 147,97 óbitos/100k hab, seguido por **Presidente Kennedy** (146,03) e **Vitória** (131,32) — indicando que o porte populacional não explica isoladamente a variação observada e que fatores locais (acesso a saúde, perfil etário) precisam ser investigados.')
lines.append('')
lines.append('## Dados Sociodemográficos do ES')
lines.append('')
lines.append('| Indicador | Valor | Fonte |')
lines.append('|-----------|-------|-------|')
lines.append('| População (Censo 2022) | 3.833.712 | IBGE |')
lines.append('| População estimada (2025) | 4.126.854 | IBGE |')
lines.append('| Área Territorial | 46.074,44 km² | IBGE |')
lines.append('| Densidade demográfica | 83,21 hab/km² | IBGE |')
lines.append('| IDH (2021) | 0,771 | PNUD |')
lines.append('| Rendimento domiciliar per capita | R$ 2.249 | IBGE/PNAD Contínua |')
lines.append('| Matrículas no ensino fundamental | 502.726 | INEP |')
lines.append('')
lines.append('## Discussão')
lines.append('')
lines.append(f'A taxa de letalidade geral do ES ({overall_rate}%) no período analisado está dentro do esperado para a primeira onda da pandemia (março a outubro de 2020). A mortalidade de {overall_deaths_per_100k} óbitos por 100 mil habitantes reflete o impacto populacional da doença.')
lines.append('')
lines.append('A análise per capita revela que municípios do interior, como Ponto Belo, Guaçuí e Alto Rio Novo, apresentaram mortalidade proporcionalmente maior, possivelmente relacionada a menor infraestrutura hospitalar (leitos de UTI, ventiladores) e maior distância dos centros de referência.')
lines.append('')
lines.append('A ausência de óbitos em Iconha (4.890 casos, 0 óbitos) permanece como um dado atípico que merece investigação adicional — pode estar relacionada a subnotificação, perfil etário da população infectada, ou fatores locais de proteção.')
lines.append('')
r2_fmt = f'{r2:.3f}'
lines.append(f'O modelo de tendência polinomial (R² = {r2_fmt}) confirma o padrão de crescimento não linear típico de epidemias, com desaceleração da taxa de crescimento diário ao final do período, sugerindo o início de um platô na primeira onda.')
lines.append('')
lines.append('## Fontes')
lines.append('')
lines.append('1. **Dataset COVID-19 ES**: `covid-es.xlsx` — casos e óbitos por município do ES (27/03/2020 a 01/10/2020).')
lines.append('2. **IBGE — SIDRA API** (Tabela 4714): https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022 — População residente (Censo 2022).')
lines.append('3. **IBGE — Cidades e Estados**: https://www.ibge.gov.br/cidades-e-estados/es/.html — Dados territoriais e socioeconômicos.')
lines.append('4. **IBGE — Censo 2022**: https://censo2022.ibge.gov.br/')
lines.append('5. **IJSN — Observatório COVID-19**: https://ijsn.es.gov.br/observatorios/observatorio-covid-19')
lines.append('6. **IJSN — Painéis Interativos**: https://ijsn.es.gov.br/paineis-interativos')
lines.append('7. **PNUD — IDH**: https://www.br.undp.org/')
lines.append('8. **DATASUS**: https://datasus.saude.gov.br/')

with open('relatorio.md', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
print('relatorio.md generated!')

# --- Generate dashboard JSON ---
dashboard_data = {
    'state': {
        'name': 'Espírito Santo',
        'code': 32,
        'total_cases': int(total_cases),
        'total_deaths': int(total_deaths),
        'death_rate': overall_rate,
        'deaths_per_100k': overall_deaths_per_100k,
        'cases_per_100k': overall_cases_per_100k,
        'population': int(state_pop),
        'period_start': df['date'].min().strftime('%Y-%m-%d'),
        'period_end': latest_date.strftime('%Y-%m-%d'),
    },
    'timeline': timeline_list,
    'municipalities': []
}

for _, row in latest.sort_values('name').iterrows():
    dashboard_data['municipalities'].append({
        'name': row['name'],
        'code': int(row['code']),
        'cases': int(row['cases']),
        'deaths': int(row['deaths']),
        'death_rate': row['death_rate'],
        'population': int(row['population']),
        'deaths_per_100k': row['deaths_per_100k'],
        'cases_per_100k': row['cases_per_100k']
    })

with open('dashboard_data.json', 'w', encoding='utf-8') as f:
    json.dump(dashboard_data, f, ensure_ascii=False, indent=2)
print('dashboard_data.json generated!')
