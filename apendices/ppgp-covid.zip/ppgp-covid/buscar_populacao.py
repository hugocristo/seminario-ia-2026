import sys
import requests
import json
import csv

sys.stdout.reconfigure(encoding='utf-8')

url = 'https://apisidra.ibge.gov.br/values/t/4714/n6/all/v/93/p/2022'
print('Consultando API IBGE SIDRA (tabela 4714 - população residente)...')
r = requests.get(url, timeout=120)
data = r.json()
print(f'Total de municípios no Brasil: {len(data) - 1}')

populacao = {}
for row in data[1:]:
    cod = row['D1C']
    if cod.startswith('32'):
        nome = row['D1N'].split(' - ')[0]
        populacao[cod] = {
            'nome': nome,
            'populacao': int(row['V'])
        }

print(f'Municípios do ES encontrados: {len(populacao)}')

# Save to CSV
with open('populacao_es.csv', 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f)
    w.writerow(['codigo', 'nome', 'populacao'])
    for cod in sorted(populacao.keys()):
        info = populacao[cod]
        w.writerow([cod, info['nome'], info['populacao']])

print('populacao_es.csv salvo!')
for cod in sorted(populacao.keys()):
    info = populacao[cod]
    print(f'  {cod}: {info["nome"]} = {info["populacao"]:,} hab')
