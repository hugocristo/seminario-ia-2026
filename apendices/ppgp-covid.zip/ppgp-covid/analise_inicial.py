import sys
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

df = pd.read_excel('covid-es.xlsx')

latest_date = df['date'].max()
latest = df[df['date'] == latest_date].copy()
latest = latest.sort_values('deaths', ascending=False)

latest['death_rate'] = (latest['deaths'] / latest['cases'] * 100).round(2)

# Save for later use
latest[['name', 'code', 'cases', 'deaths', 'death_rate']].to_csv('municipios_es.csv', index=False, encoding='utf-8')

print("Dados salvos em municipios_es.csv")
print(f"Municípios: {len(latest)}")
print(f"Período: {df['date'].min()} a {latest_date}")
print(f"Total casos: {latest['cases'].sum()}")
print(f"Total óbitos: {latest['deaths'].sum()}")
print(f"Taxa letalidade geral: {latest['deaths'].sum()/latest['cases'].sum()*100:.2f}%")
