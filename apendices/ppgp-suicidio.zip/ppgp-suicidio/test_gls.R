library(nlme)
es <- data.frame(
  taxa = c(4.950817, 4.645521, 4.962793, 4.785902, 5.035904, 4.958407, 5.445347, 4.581031, 4.988726, 5.359743, 4.988798),
  t = 1:11
)
es$log_y <- log10(es$taxa)
mod <- gls(log_y ~ t, data=es, correlation=corAR1(form=~t), method='ML')
s <- summary(mod)
cat('Coef:', coef(mod), '\n')
cat('Pval t:', s$tTable['t','p-value'], '\n')
