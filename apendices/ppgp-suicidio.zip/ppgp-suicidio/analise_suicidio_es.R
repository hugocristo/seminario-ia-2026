# Análise de tendência temporal de mortalidade por suicídio no Espírito Santo
# Todas as mesorregiões e microrregiões IBGE - 2006-2016
# Regressão de Prais-Winsten, padronização direta por idade (Censo 2010)

suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(nlme)
})

source("prais_gls.R")

# ─── 1. CARREGAR DADOS ────────────────────────────────────────────────────────

obitos <- read_excel("suicidios-es.xlsx") |>
  mutate(across(where(is.character), trimws))

mun_map <- read.csv("mun_mapeamento.csv", encoding = "UTF-8", stringsAsFactors = FALSE) |>
  mutate(cod_mun = as.character(cod_mun))

pop_anual <- read.csv("pop_es_municipios.csv", encoding = "UTF-8", stringsAsFactors = FALSE) |>
  mutate(cod_mun = as.character(cod_mun))

censo_total <- read.csv("censo2010_faixaetaria_es.csv", encoding = "UTF-8", stringsAsFactors = FALSE) |>
  mutate(cod_mun = as.character(cod_mun))

censo_sexo <- read.csv("censo2010_sexo_faixaetaria_es.csv", encoding = "UTF-8", stringsAsFactors = FALSE) |>
  mutate(cod_mun = as.character(cod_mun))

# ─── 2. JUNTAR CÓDIGO IBGE E REGIÕES AOS DADOS ───────────────────────────────

# Regiões (meso/micro) por município dos óbitos
mun_regioes <- obitos |>
  select(meso, micro, municipio) |>
  distinct() |>
  left_join(mun_map, by = c("municipio" = "mun_obitos"))

# Adicionar cod_mun à base de população
pop_anual <- pop_anual |>
  left_join(
    mun_regioes |> select(cod_mun, meso, micro),
    by = "cod_mun"
  )

sem_regiao <- pop_anual |> filter(is.na(meso)) |> select(nome_mun) |> distinct()
if (nrow(sem_regiao) > 0) {
  message("Municípios sem região: ", paste(sem_regiao$nome_mun, collapse = ", "))
}

pop_anual <- pop_anual |> filter(!is.na(meso))

# Adicionar cod_mun ao censo
censo_total <- censo_total |>
  left_join(mun_regioes |> select(cod_mun, meso, micro), by = "cod_mun")

censo_sexo <- censo_sexo |>
  left_join(mun_regioes |> select(cod_mun, meso, micro), by = "cod_mun")

# ─── 3. MAPEAMENTO DE FAIXAS ETÁRIAS ─────────────────────────────────────────

# Óbitos: grupos de 10 anos
mapa_faixa_obitos <- c(
  "15 a 19 anos" = "15_29",
  "20 a 29 anos" = "15_29",
  "30 a 39 anos" = "30_59",
  "40 a 49 anos" = "30_59",
  "50 a 59 anos" = "30_59",
  "60 a 69 anos" = "60mais",
  "70 a 79 anos" = "60mais",
  "80 anos e mais" = "60mais"
)

# Censo: grupos quinquenais
mapa_faixa_censo <- c(
  "15 a 19 anos" = "15_29",
  "20 a 24 anos" = "15_29",
  "25 a 29 anos" = "15_29",
  "30 a 34 anos" = "30_59",
  "35 a 39 anos" = "30_59",
  "40 a 44 anos" = "30_59",
  "45 a 49 anos" = "30_59",
  "50 a 54 anos" = "30_59",
  "55 a 59 anos" = "30_59",
  "60 a 64 anos" = "60mais",
  "65 a 69 anos" = "60mais",
  "70 a 74 anos" = "60mais",
  "75 a 79 anos" = "60mais",
  "80 a 89 anos" = "60mais",
  "90 a 99 anos" = "60mais",
  "100 anos ou mais" = "60mais"
)

# ─── 4. POPULAÇÃO PADRÃO (Censo 2010 ES, para padronização direta) ────────────

pop_padrao <- censo_total |>
  filter(faixa_etaria %in% names(mapa_faixa_censo), !is.na(meso)) |>
  mutate(grupo = mapa_faixa_censo[faixa_etaria]) |>
  group_by(grupo) |>
  summarise(pop_padrao = sum(populacao_2010), .groups = "drop")

pop_padrao_sexo <- censo_sexo |>
  filter(faixa_etaria %in% names(mapa_faixa_censo), !is.na(meso)) |>
  mutate(grupo = mapa_faixa_censo[faixa_etaria]) |>
  group_by(sexo, grupo) |>
  summarise(pop_padrao = sum(populacao_2010), .groups = "drop")

# ─── 5. PROPORÇÕES POR MUNICÍPIO DO CENSO 2010 ────────────────────────────────

# Proporção de cada grupo etário no total ≥15 anos
prop_faixa_mun <- censo_total |>
  filter(faixa_etaria %in% names(mapa_faixa_censo), !is.na(meso)) |>
  mutate(grupo = mapa_faixa_censo[faixa_etaria]) |>
  group_by(cod_mun, grupo) |>
  summarise(pop_grupo = sum(populacao_2010), .groups = "drop") |>
  group_by(cod_mun) |>
  mutate(prop_grupo = pop_grupo / sum(pop_grupo)) |>
  ungroup()

prop_faixa_sexo_mun <- censo_sexo |>
  filter(faixa_etaria %in% names(mapa_faixa_censo), !is.na(meso)) |>
  mutate(grupo = mapa_faixa_censo[faixa_etaria]) |>
  group_by(cod_mun, sexo, grupo) |>
  summarise(pop_grupo = sum(populacao_2010), .groups = "drop") |>
  group_by(cod_mun, sexo) |>
  mutate(prop_grupo = pop_grupo / sum(pop_grupo)) |>
  ungroup()

# Proporção ≥15 anos no total municipal
prop_acima15 <- censo_total |>
  filter(!is.na(meso)) |>
  mutate(acima15 = faixa_etaria %in% names(mapa_faixa_censo)) |>
  group_by(cod_mun) |>
  summarise(
    prop_acima15       = sum(populacao_2010[acima15]) / sum(populacao_2010),
    pop_acima15_censo  = sum(populacao_2010[acima15]),
    .groups = "drop"
  )

prop_acima15_sexo <- censo_sexo |>
  filter(!is.na(meso)) |>
  mutate(acima15 = faixa_etaria %in% names(mapa_faixa_censo)) |>
  group_by(cod_mun, sexo) |>
  summarise(
    pop_acima15_sexo = sum(populacao_2010[acima15]),
    pop_total_sexo   = sum(populacao_2010),
    .groups = "drop"
  ) |>
  left_join(select(prop_acima15, cod_mun, pop_acima15_censo), by = "cod_mun") |>
  mutate(prop_sexo_acima15 = pop_acima15_sexo / pop_acima15_censo)

# ─── 6. CONSTRUIR DENOMINADORES ANUAIS ───────────────────────────────────────

# Por município × ano × grupo etário
pop_mun_grp <- pop_anual |>
  left_join(select(prop_acima15, cod_mun, prop_acima15), by = "cod_mun") |>
  crossing(grupo = c("15_29","30_59","60mais")) |>
  left_join(select(prop_faixa_mun, cod_mun, grupo, prop_grupo), by = c("cod_mun","grupo")) |>
  mutate(pop_grp = populacao * prop_acima15 * prop_grupo)

# Por município × ano × sexo
pop_mun_sex <- pop_anual |>
  left_join(select(prop_acima15, cod_mun, prop_acima15), by = "cod_mun") |>
  crossing(sexo = c("Masc","Fem")) |>
  left_join(select(prop_acima15_sexo, cod_mun, sexo, prop_sexo_acima15), by = c("cod_mun","sexo")) |>
  mutate(pop_sex = populacao * prop_acima15 * prop_sexo_acima15)

# ─── 7. AGREGAR ÓBITOS ────────────────────────────────────────────────────────

# Óbitos por faixa etária (corte = "idade")
ob_faixa <- obitos |>
  filter(corte == "idade", fator %in% names(mapa_faixa_obitos)) |>
  mutate(grupo = mapa_faixa_obitos[fator])

# Óbitos por sexo
ob_sexo <- obitos |>
  filter(corte == "sexo", fator %in% c("Masc","Fem")) |>
  rename(sexo = fator)

# Função auxiliar: agregar por nível geográfico
agg_nivel <- function(ob_df, pop_df, grupo_var, nivel) {
  if (nivel == "estado") {
    ob_agg  <- ob_df  |> group_by(ano, .data[[grupo_var]]) |> summarise(n = sum(total), .groups="drop") |> mutate(regiao="Espírito Santo")
    pop_agg <- pop_df |> group_by(ano, .data[[grupo_var]]) |> summarise(pop = sum(.data[[paste0("pop_",substr(grupo_var,1,3))]], na.rm=TRUE), .groups="drop") |> mutate(regiao="Espírito Santo")
  } else {
    col <- if (nivel == "meso") "meso" else "micro"
    ob_agg  <- ob_df  |> group_by(.data[[col]], ano, .data[[grupo_var]]) |> summarise(n = sum(total), .groups="drop") |> rename(regiao = !!col)
    pop_agg <- pop_df |> group_by(.data[[col]], ano, .data[[grupo_var]]) |> summarise(pop = sum(.data[[paste0("pop_",substr(grupo_var,1,3))]], na.rm=TRUE), .groups="drop") |> rename(regiao = !!col)
  }
  left_join(ob_agg, pop_agg, by = c("regiao","ano",grupo_var)) |> mutate(nivel = nivel)
}

# Pop geral (>= 15 anos)
pop_mun_geral <- pop_anual |>
  left_join(select(prop_acima15, cod_mun, prop_acima15), by="cod_mun") |>
  mutate(pop_ger = populacao * prop_acima15)

ob_geral <- obitos |>
  filter(corte == "sexo", fator %in% c("Masc","Fem")) |>
  group_by(meso, micro, municipio, ano) |>
  summarise(total = sum(total), .groups="drop")

# Agregar óbitos por grupo etário
ob_grp_es   <- ob_faixa |> group_by(ano, grupo) |> summarise(n=sum(total),.groups="drop") |> mutate(regiao="Espírito Santo", nivel="estado")
ob_grp_meso <- ob_faixa |> group_by(meso, ano, grupo) |> summarise(n=sum(total),.groups="drop") |> rename(regiao=meso) |> mutate(nivel="meso")
ob_grp_micro<- ob_faixa |> group_by(micro, ano, grupo) |> summarise(n=sum(total),.groups="drop") |> rename(regiao=micro) |> mutate(nivel="micro")
ob_grp_all  <- bind_rows(ob_grp_es, ob_grp_meso, ob_grp_micro)

# Agregar pop por grupo etário
pop_grp_es   <- pop_mun_grp |> group_by(ano, grupo) |> summarise(pop=sum(pop_grp,na.rm=T),.groups="drop") |> mutate(regiao="Espírito Santo", nivel="estado")
pop_grp_meso <- pop_mun_grp |> group_by(meso, ano, grupo) |> summarise(pop=sum(pop_grp,na.rm=T),.groups="drop") |> rename(regiao=meso) |> mutate(nivel="meso")
pop_grp_micro<- pop_mun_grp |> group_by(micro, ano, grupo) |> summarise(pop=sum(pop_grp,na.rm=T),.groups="drop") |> rename(regiao=micro) |> mutate(nivel="micro")
pop_grp_all  <- bind_rows(pop_grp_es, pop_grp_meso, pop_grp_micro)

# Agregar óbitos por sexo
ob_sex_es   <- ob_sexo |> group_by(ano, sexo) |> summarise(n=sum(total),.groups="drop") |> mutate(regiao="Espírito Santo", nivel="estado")
ob_sex_meso <- ob_sexo |> group_by(meso, ano, sexo) |> summarise(n=sum(total),.groups="drop") |> rename(regiao=meso) |> mutate(nivel="meso")
ob_sex_micro<- ob_sexo |> group_by(micro, ano, sexo) |> summarise(n=sum(total),.groups="drop") |> rename(regiao=micro) |> mutate(nivel="micro")
ob_sex_all  <- bind_rows(ob_sex_es, ob_sex_meso, ob_sex_micro)

# Agregar pop por sexo
pop_sex_es   <- pop_mun_sex |> group_by(ano, sexo) |> summarise(pop=sum(pop_sex,na.rm=T),.groups="drop") |> mutate(regiao="Espírito Santo", nivel="estado")
pop_sex_meso <- pop_mun_sex |> group_by(meso, ano, sexo) |> summarise(pop=sum(pop_sex,na.rm=T),.groups="drop") |> rename(regiao=meso) |> mutate(nivel="meso")
pop_sex_micro<- pop_mun_sex |> group_by(micro, ano, sexo) |> summarise(pop=sum(pop_sex,na.rm=T),.groups="drop") |> rename(regiao=micro) |> mutate(nivel="micro")
pop_sex_all  <- bind_rows(pop_sex_es, pop_sex_meso, pop_sex_micro)

# Geral (>= 15 anos)
ob_ger_es   <- ob_geral |> group_by(ano) |> summarise(n=sum(total),.groups="drop") |> mutate(regiao="Espírito Santo", nivel="estado")
ob_ger_meso <- ob_geral |> group_by(meso, ano) |> summarise(n=sum(total),.groups="drop") |> rename(regiao=meso) |> mutate(nivel="meso")
ob_ger_micro<- ob_geral |> group_by(micro, ano) |> summarise(n=sum(total),.groups="drop") |> rename(regiao=micro) |> mutate(nivel="micro")
ob_ger_all  <- bind_rows(ob_ger_es, ob_ger_meso, ob_ger_micro)

pop_ger_es   <- pop_mun_geral |> group_by(ano) |> summarise(pop=sum(pop_ger,na.rm=T),.groups="drop") |> mutate(regiao="Espírito Santo", nivel="estado")
pop_ger_meso <- pop_mun_geral |> group_by(meso, ano) |> summarise(pop=sum(pop_ger,na.rm=T),.groups="drop") |> rename(regiao=meso) |> mutate(nivel="meso")
pop_ger_micro<- pop_mun_geral |> group_by(micro, ano) |> summarise(pop=sum(pop_ger,na.rm=T),.groups="drop") |> rename(regiao=micro) |> mutate(nivel="micro")
pop_ger_all  <- bind_rows(pop_ger_es, pop_ger_meso, pop_ger_micro)

# ─── 8. CALCULAR TAXAS ────────────────────────────────────────────────────────

# Taxas por grupo etário (brutas)
taxa_grp <- ob_grp_all |>
  left_join(pop_grp_all, by=c("regiao","nivel","ano","grupo")) |>
  mutate(taxa = n / pop * 100000)

# Taxas padronizadas (pop geral): soma ponderada com pop padrão
taxa_pad_geral <- taxa_grp |>
  left_join(pop_padrao, by="grupo") |>
  group_by(regiao, nivel, ano) |>
  summarise(
    obitos  = sum(n),
    pop     = sum(pop),
    taxa_bruta = sum(n) / sum(pop) * 100000,
    taxa_pad   = weighted.mean(taxa, pop_padrao, na.rm=TRUE),
    .groups = "drop"
  )

# Taxas por sexo
taxa_sex <- ob_sex_all |>
  left_join(pop_sex_all, by=c("regiao","nivel","ano","sexo")) |>
  mutate(taxa_pad = n / pop * 100000)

# Taxas brutas geral
taxa_ger <- ob_ger_all |>
  left_join(pop_ger_all, by=c("regiao","nivel","ano")) |>
  mutate(taxa = n / pop * 100000)

# ─── 9. REGRESSÃO PRAIS-WINSTEN ──────────────────────────────────────────────

# prais_apc is loaded from prais_gls.R

# Aplicar regressão
run_prais <- function(df_grouped, var_taxa) {
  df_grouped |>
    group_modify(~as_tibble(prais_apc(.x, var_taxa))) |>
    ungroup()
}

# Geral
tend_geral <- taxa_pad_geral |>
  group_by(regiao, nivel) |>
  run_prais("taxa_pad") |>
  mutate(estratificacao="Geral")

# Por sexo
tend_sex <- taxa_sex |>
  group_by(regiao, nivel, sexo) |>
  run_prais("taxa_pad") |>
  rename(estratificacao=sexo) |>
  mutate(estratificacao=recode(estratificacao,"Masc"="Masculino","Fem"="Feminino"))

# Por faixa etária
tend_grp <- taxa_grp |>
  group_by(regiao, nivel, grupo) |>
  run_prais("taxa") |>
  rename(estratificacao=grupo) |>
  mutate(estratificacao=recode(estratificacao,
    "15_29"="15-29 anos","30_59"="30-59 anos","60mais"="60 anos ou mais"))

# Combinar
tend_all <- bind_rows(tend_geral, tend_sex, tend_grp) |>
  mutate(nivel=factor(nivel, levels=c("estado","meso","micro")))

# ─── 10. TABELA DESCRITIVA ────────────────────────────────────────────────────

# Total de óbitos por região, sexo e faixa etária (2006-2016)
desc_sexo <- ob_sex_all |>
  group_by(regiao, nivel, sexo) |>
  summarise(n=sum(n), .groups="drop")

desc_grp <- ob_grp_all |>
  group_by(regiao, nivel, grupo) |>
  summarise(n=sum(n), .groups="drop") |>
  mutate(grupo=recode(grupo,"15_29"="15-29 anos","30_59"="30-59 anos","60mais"="60 anos ou mais"))

desc_total <- ob_ger_all |>
  group_by(regiao, nivel) |>
  summarise(n=sum(n), .groups="drop") |>
  mutate(categoria="Total")

# ─── 11. SALVAR ──────────────────────────────────────────────────────────────

dir.create("resultados", showWarnings=FALSE)
write.csv(tend_all,        "resultados/tendencias.csv",         row.names=FALSE, fileEncoding="UTF-8")
write.csv(taxa_pad_geral,  "resultados/taxas_padronizadas.csv", row.names=FALSE, fileEncoding="UTF-8")
write.csv(taxa_sex,        "resultados/taxas_sexo.csv",         row.names=FALSE, fileEncoding="UTF-8")
write.csv(taxa_grp,        "resultados/taxas_faixa.csv",        row.names=FALSE, fileEncoding="UTF-8")
write.csv(desc_sexo,       "resultados/desc_sexo.csv",          row.names=FALSE, fileEncoding="UTF-8")
write.csv(desc_grp,        "resultados/desc_faixa.csv",         row.names=FALSE, fileEncoding="UTF-8")
write.csv(desc_total,      "resultados/desc_total.csv",         row.names=FALSE, fileEncoding="UTF-8")

message("Concluído. Resultados em ./resultados/")
