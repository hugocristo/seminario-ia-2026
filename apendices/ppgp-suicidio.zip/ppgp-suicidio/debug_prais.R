suppressPackageStartupMessages({library(dplyr); library(prais)})

t <- read.csv("resultados/taxas_padronizadas.csv", encoding="UTF-8", stringsAsFactors=FALSE)
cat("Rows:", nrow(t), "\n")
cat("Cols:", paste(names(t), collapse=", "), "\n")
cat("Regioes:", paste(unique(t$regiao), collapse=", "), "\n\n")

# Test with ES
es <- t[t$nivel == "estado", ]
cat("ES rows:", nrow(es), "\n")
cat("ES taxa_pad:", es$taxa_pad, "\n")
cat("Finite:", sum(is.finite(es$taxa_pad)), "\n\n")

es2 <- es[is.finite(es$taxa_pad) & es$taxa_pad > 0, ]
es2 <- es2[order(es2$ano), ]
es2$log_y <- log10(es2$taxa_pad)
es2$t <- seq_len(nrow(es2))
cat("n obs:", nrow(es2), "\n")
cat("log_y:", es2$log_y, "\n")

mod <- tryCatch(
  prais_winsten(log_y ~ t, data = es2),
  error = function(e) { cat("Error:", conditionMessage(e), "\n"); NULL }
)
if (!is.null(mod)) {
  cat("Coefficients:", coef(mod), "\n")
  cat("Summary:\n")
  print(summary(mod)$coefficients)
}
