# Função Prais-Winsten via GLS com erros AR(1)
# Implementação equivalente à usada no artigo original

prais_apc <- function(df, var_taxa) {
  df <- df[order(df$ano), ]
  y  <- df[[var_taxa]]
  ok <- is.finite(y) & y > 0
  df <- df[ok, ]
  if (nrow(df) < 5) return(data.frame(apc=NA, ic_inf=NA, ic_sup=NA, pval=NA, tendencia="Insuf."))

  df$log_y <- log10(y[ok])
  df$t     <- seq_len(nrow(df))

  tryCatch({
    mod <- nlme::gls(log_y ~ t, data=df,
                     correlation=nlme::corAR1(form=~t),
                     method="ML")
    s    <- summary(mod)
    b1   <- coef(mod)[["t"]]
    se   <- s$tTable["t","Std.Error"]
    pv   <- s$tTable["t","p-value"]
    df_r <- s$dims$N - s$dims$p

    tc <- qt(0.975, df_r)
    apc    <- (10^b1  - 1) * 100
    ic_inf <- (10^(b1 - tc*se) - 1) * 100
    ic_sup <- (10^(b1 + tc*se) - 1) * 100
    tend   <- if (!is.na(pv) && pv < 0.05) {
      if (b1 > 0) "Crescente" else "Decrescente"
    } else "Estacionária"

    data.frame(apc=round(apc,1), ic_inf=round(ic_inf,1), ic_sup=round(ic_sup,1),
               pval=round(pv,3), tendencia=tend, stringsAsFactors=FALSE)
  }, error=function(e) {
    data.frame(apc=NA, ic_inf=NA, ic_sup=NA, pval=NA, tendencia="Erro", stringsAsFactors=FALSE)
  })
}
